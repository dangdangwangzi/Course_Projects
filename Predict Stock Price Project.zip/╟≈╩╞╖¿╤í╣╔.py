# 导入函数库
from jqdata import *

# 初始化函数，设定基准等等
def initialize(context):
    # 设定沪深300作为基准
    set_benchmark('000300.XSHG')
    # 开启动态复权模式(真实价格)
    set_option('use_real_price', True)
    # 输出内容到日志 log.info()
    log.info('初始函数开始运行且全局只运行一次')
    # 过滤掉order系列API产生的比error级别低的log
    # log.set_level('order', 'error')

    ### 股票相关设定 ###
    # 股票类每笔交易时的手续费是：买入时佣金万分之三，卖出时佣金万分之三加千分之一印花税, 每笔交易佣金最低扣5块钱
    set_order_cost(OrderCost(close_tax=0.001, open_commission=0.0003, close_commission=0.0003, min_commission=5), type='stock')
    
    #设置股票池
    g.scu = get_index_stocks('000001.XSHG')+get_index_stocks('399106.XSHE')
    #设置短、中、长期的周期长度
    g.D1 = 5
    g.D2 = 15
    g.D3 = 80
    g.tend_last_short = dict.fromkeys(g.scu, 0)
    g.tend_last_middle = dict.fromkeys(g.scu, 0)
    g.tend_last_long = dict.fromkeys(g.scu, 0)
    #设置计算波动周期
    g.D4 = 10
    #最多买多少只股票
    g.maxinnum = 10
    g.downrate = 0.1 #抛售波动比例
    g.outrate = 0.01 #抛售亏损占总金比例
    g.addrate = 0.015 #判断是否盈利加码
    g.refresh_rate = 1
    g.days = 0 #调仓计时器
    g.zombie_stock = 50000000  # 僵尸股成交额筛选参数，建议1亿，约有1000股入选，越大入选股越少
    ## 运行函数（reference_security为运行时间的参考标的；传入的标的只做种类区分，因此传入'000300.XSHG'或'510300.XSHG'是一样的）
      # 开盘前运行
    #run_daily(before_market_open, time='before_open', reference_security='000300.XSHG')
      # 开盘时运行
    run_daily(market_open, time='open', reference_security='000300.XSHG')
 
# ## 开盘前运行函数
# def before_market_open(context):
#     # 输出运行时间
#     log.info('函数运行时间(before_market_open)：'+str(context.current_dt.time()))

#     # 给微信发送消息（添加模拟交易，并绑定微信生效）
#     # send_message('美好的一天~')

## 开盘时运行函数
def market_open(context):
    log.info('函数运行时间(market_open):'+str(context.current_dt.time()))
    if g.days%g.refresh_rate == 0:
        #初始化趋势：{短，中，长}*所有股票，正值时为上升趋势，负值时为下降趋势，0为持平趋势
        tend_short = dict.fromkeys(g.scu, 0)
        tend_middle = dict.fromkeys(g.scu, 0)
        tend_long = dict.fromkeys(g.scu, 0)
        m_period = [g.D1,g.D2,g.D3]
        m_tend = [tend_short, tend_middle, tend_long]
        for i in range(2):
            m_price = get_price(g.scu, count=m_period[i], end_date=context.previous_date, frequency='daily', fields=['close']) #查询前Di日内所有闭盘价格    
            last_price = m_price['close'][m_period[i]-1:m_period[i]]    
            max_price = m_price['close'].max(axis=0)
            min_price = m_price['close'].min(axis=0)
            mean_price = m_price['close'].mean(axis=0)
            for m_stock,m_value in last_price.iteritems():
                if m_value.values == max_price[m_stock]:
                    m_tend[i][m_stock] = m_value.values - mean_price[m_stock] #上升趋势，上升幅度为该日价格-Di内的平均价
                elif m_value.values == min_price[m_stock]:
                    m_tend[i][m_stock] = m_value.values - mean_price[m_stock]#下降趋势，上升幅度为该日价格-Di内的平均价
        
        #初始化股价波动：收盘价
        fluctuation = dict.fromkeys(g.scu, 0)
        m_price = get_price(g.scu, count=g.D4, end_date=context.previous_date, frequency='daily', fields=['close']) #查询前Di日内所有闭盘价格
        mean_price = m_price['close'].mean(axis=0)
        for m_stock in fluctuation:
            sum = 0.0
            for i in range(g.D4):
                bais = m_price['close'][i:i+1][m_stock].values-mean_price[m_stock]
                sum += bais*bais
            fluctuation[m_stock] = pow(sum,0.5)
            
        #卖出
        selllist = list()
        for m_stock in context.portfolio.positions:
            if tend_short[m_stock]< (- g.downrate*fluctuation[m_stock]) or tend_middle[m_stock]< -fluctuation[m_stock]*g.downrate:
                selllist.append(m_stock)
        for stock in selllist: #如果stock不在buylist
              order_target(stock, 0) #调整stock的持仓为0，即卖出
              print('***********************SELL***********************')
        
        #追加
        for m_stock in context.portfolio.positions:
            profit = context.portfolio.positions[m_stock].value-context.portfolio.positions[m_stock].price*context.portfolio.positions[m_stock].closeable_amount
            if profit>context.portfolio.positions_value*g.addrate:
                print('***********************ADD***********************')
                order(g.security, int(context.portfolio.positions[stock].closeable_amount/2))
        
        #买入
        buylist = list()
        temp = sorted(tend_middle.items(), key=lambda item:item[1], reverse=True)[0:g.maxinnum]
        for m_stock,tempvalue in temp:
            if (m_stock not in context.portfolio.positions) and (tend_short[m_stock]>0) and (tend_middle[m_stock]>0):
                buylist.append(m_stock)
        buylist = filter_specials(buylist,context)
        if (len(buylist)>0):
            # 将资金分成g.stocksnum份
            position_per_stk = context.portfolio.cash/len(buylist)
            # 用position_per_stk大小的g.stocksnum份资金去买buylist中的股票
            for stock in buylist:
                order_value(stock, position_per_stk)
        # #更新tend_last
        # g.tend_last_short = tend_short.copy()
        # g.tend_last_middle = tend_middle.copy()
        # g.tend_last_long = tend_long.copy()
        # security = g.security
        # # 获取股票的收盘价
        # close_data = get_bars('000300.XSHG', count=5, unit='1d', fields=['close'])
        # # 取得过去五天的平均价格
        # MA5 = close_data['close'].mean()
        # print(type(close_data))
        # # 取得上一时间点价格
        # current_price = close_data['close'][-1]
        # # 取得当前的现金
        # cash = context.portfolio.available_cash
    
        # # 如果上一时间点价格高出五天平均价1%, 则全仓买入
        # if current_price > 1.01*MA5:
        #     # 记录这次买入
        #     log.info("价格高于均价 1%%, 买入 %s" % (security))
        #     # 用所有 cash 买入股票
        #     order_value(security, cash)
        # # 如果上一时间点价格低于五天平均价, 则空仓卖出
        # elif current_price < MA5 and context.portfolio.positions[security].closeable_amount > 0:
        #     # 记录这次卖出
        #     log.info("价格低于均价, 卖出 %s" % (security))
        #     # 卖出所有股票,使这只股票的最终持有量为0
        #     order_target(security, 0)
        g.days = 1
    else:
        g.days += 1
#过滤股票
def filter_specials(stock_list, context):
    curr_data = get_current_data()
    h = history(5, '1d', 'money', stock_list, df=False)
    stock_list = [stock for stock in stock_list if \
                  (not curr_data[stock].paused)  # 未停牌
                  and (not curr_data[stock].is_st)  # 非ST
                  and ('ST' not in curr_data[stock].name)
                  and ('*' not in curr_data[stock].name)
                  and ('退' not in curr_data[stock].name)
                  and (curr_data[stock].low_limit < curr_data[stock].day_open < curr_data[stock].high_limit)
                  and (h[stock].mean() > g.zombie_stock)]
    return stock_list



# def buy_stock(context, dict_short,dict_middle,dict_long,dict_fluc):
#     buy_list = list()
#     for m_stock in dict_short:
#         if (m_stock not in context.portfolio.positions) and (dict_short[m_stock]<0) and (dict_middle[m_stock]>0):
#             buy_list.append(m_stock)
#     return buy_list

# #包括止损和盈利
# def sell_stock(context,dict_short,dict_middle,dict_long,dict_fluc):
#     sell_list = list()
#     for m_stock in dict_short:
#         if (m_stock in context.portfolio.positions) and (dict_short[m_stock]< (- dict_fluc[m_stock]*2)):
#             sell_list.append(m_stock)
#     return sell_list

# def buy_rise(dict_short,dict_middle,dict_long,dict_fluc):
    
#     return rise_list