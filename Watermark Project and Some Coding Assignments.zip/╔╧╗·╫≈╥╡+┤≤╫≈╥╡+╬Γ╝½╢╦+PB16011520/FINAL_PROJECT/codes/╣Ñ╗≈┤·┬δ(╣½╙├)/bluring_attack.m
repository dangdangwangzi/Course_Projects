function X_B=bluring_attack(X)
PSF=fspecial('gaussian',7,10);
X_B=imfilter(X,PSF);


end