function X_RS2=resampling_attack(X)
%if_colorful_input
if(length(size(X)==3))
Y=X(:,:,1);
U=X(:,:,2);
V=X(:,:,3);
Y_RS=resample(double(Y),2,1);
Y_RS1=resample(double(Y_RS'),2,1);
Y_RS2=imresize(Y_RS1',0.5);

U_RS=resample(double(U),2,1);
U_RS1=resample(double(U_RS'),2,1);
U_RS2=imresize(U_RS1',0.5);

V_RS=resample(double(V),2,1);
V_RS1=resample(double(V_RS'),2,1);
V_RS2=imresize(V_RS1',0.5);

X_RS2=cat(3,Y_RS2,U_RS2,V_RS2);
else
X_RS=resample(double(X),2,1);
X_RS1=resample(double(X_RS'),2,1);
%resize
X_RS2=imresize(X_RS1',0.5);
end

end