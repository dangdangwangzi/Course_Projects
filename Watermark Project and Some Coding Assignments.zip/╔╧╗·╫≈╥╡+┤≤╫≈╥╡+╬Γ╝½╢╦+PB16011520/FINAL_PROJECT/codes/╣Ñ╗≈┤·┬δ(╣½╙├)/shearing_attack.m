function [X_LU,X_RD]=shearing_attack(X)
%if_colorful_input
if length(size(X))==3
Y=X(:,:,1);
U=X(:,:,2);
V=X(:,:,3);
[m,n]=size(U);
Y_LU=Y;
Y_LU(1:round(m/2),1:round(n/2))=0;
Y_RD=Y;
Y_RD(round(m/2)+1:end,round(n/2)+2:end)=0;

U_LU=U;
U_LU(1:round(m/2),1:round(n/2))=0;
U_RD=U;
U_RD(round(m/2)+1:end,round(n/2)+2:end)=0;

V_LU=V;
V_LU(1:round(m/2),1:round(n/2))=0;
V_RD=V;
V_RD(round(m/2)+1:end,round(n/2)+2:end)=0;
X_LU=cat(3,Y_LU,U_LU,V_LU);
X_RD=cat(3,Y_RD,U_RD,V_RD);
%if_gray_input
else
[m,n]=size(X);
%shear_left_up_corner
X_LU=X;
X_LU(1:round(m/2),1:round(n/2))=0;
%shear_right_down_corner
X_RD=X;
X_RD(round(m/2)+1:end,round(n/2)+2:end)=0;
% end
end