function X_N=noise_attack(X)
%cute_noises!
X_N=imnoise(X,'salt & pepper',0.02);


end