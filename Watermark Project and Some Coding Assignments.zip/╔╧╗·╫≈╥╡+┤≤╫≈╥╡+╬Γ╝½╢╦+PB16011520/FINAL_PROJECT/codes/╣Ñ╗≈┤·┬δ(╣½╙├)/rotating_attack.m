function [X_R]=rotating_attack(X)
%'crop'-rotate_without_changing_size
X_R=imrotate(X,10,'bilinear','crop');

end