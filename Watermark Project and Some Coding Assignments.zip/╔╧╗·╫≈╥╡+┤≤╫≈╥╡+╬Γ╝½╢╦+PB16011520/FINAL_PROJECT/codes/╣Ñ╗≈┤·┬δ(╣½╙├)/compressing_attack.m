function X_C=compressing_attack(X)
imwrite(X,'compressed_desert.jpg','jpeg','Quality',70);
X_C=imread('compressed_desert.jpg');


end 