%X_original_image
%I_noise_of_watermark
%wav_wavelet_function
%lev_decomposition_level
%N_embedding_level
%O_which_direction_frequency_H_V_D
%horizontal_vertical_diagnal
function Y=MY_DU_IN(X,I,wav,lev,N,O)
%wavedec2_returns_the_wavelet_decomposition_of_the_matrix_X_at_level_N
%Outputs_are_the_decomposition_vector_C and_the_corresponding_bookkeeping_matrix_S.
%Vector C is organized as a vector with A(N), H(N), V(N), D(N),
%H(N-1), V(N-1), D(N-1), ..., H(1), V(1), D(1), 
%where A, H, V, and D are each a row vector. 
%Each vector is the vector column-wise storage of a matrix.
%in_other_words_they_are_all_transformed_into_1_D_vector
[C,S]=wavedec2(X,lev,wav);

%get_coefficent_of_selected_passage
HH=detcoef2(O,C,S,N);
%judge_the_frequency
%horizontal_coefficient
if(O=='H')
    t=1;
%vertical_coefficient
elseif(O=='V')
    t=2;
elseif(O=='D')
%diagnal_coefficient
    t=3;
else
    msg='Wrong Input of N';
    errors(msg);
end
%k_is_the_intensity
%add_noise
k=2;
H1=HH+k*I;
[mH,nH]=size(H1);
%change_the_signal_to _one_demension
HH1=reshape(H1,[1,mH*nH]);
CS1=S(lev+2-N,1)*S(lev+2-N,2)*t+1;
CS2=S(lev+2-N,1)*S(lev+2-N,2)*(t+1);
%replace_the_signal
C(CS1:CS2)=HH1;
%rebuild_the_image
Y=waverec2(C,S,wav);



end