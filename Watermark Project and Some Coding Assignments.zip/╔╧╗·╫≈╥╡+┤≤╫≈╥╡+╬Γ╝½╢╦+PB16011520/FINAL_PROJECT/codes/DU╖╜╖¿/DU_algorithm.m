%use_gray_value_image
%generate_watermark
%expectation
m=0;
%variance
v=1;
m1=25;
n1=25;
%Gaussian_noise
I=normrnd(m,sqrt(v),m1,n1);

X=imread('desert_gray.jpg');
[MX,NX]=size(X);
%set_decomposition_level
N=2;
lev=5;
%robotness_of_the_code
if(m1>MX||n1>NX)
    msg='Oversize watermark';
    error(msg);   
end

if(lev<N)
    msg='Not enough decomposition level';
    error(msg);
end
%extend_water_mark_to_the_size_of_host_image
%0-extension
IZ=[I,zeros(m1,NX/2^N-n1);zeros(MX/2^N-m1,NX/2^N)];
%embed_watermark_to_level_N_passage_H
Y=MY_DU_IN(X,IZ,'haar',lev,N,'H');

%show_images
figure(1)
subplot(1,3,1)
imshow(X,[]);
title('Original Image');

subplot(1,3,2)
imshow(uint8(Y),[]);
title('Image with watermark');

subplot(1,3,3)
imshow(X-uint8(Y),[]);
title('Differences');

%store_images
imwrite(uint8(Y),'Desert_with_watermark.jpg','jpg');
imwrite(uint8(X-uint8(Y)),'Differences_Desert.jpg','jpg');

LN=5;
%read_watermark
[t,l]=MY_DU_OUT(X,Y,I,'haar',LN);
%calculate_peak_signal-to-noise_ratio
peak=psnr(X,uint8(Y));
fprintf('Peak signal-to-noise ratio:%f,Detected watermark position:level %d,passage%d.\n',peak,l,t)







