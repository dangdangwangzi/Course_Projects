%X_original_image
%Y_image_with_watermark
%I_watermark
%wav_wavelet_function
%LN_decomposition_level_number

function [t,l]=MY_DU_OUT(X,Y,I,wav,LN)
%Vector C is organized as a vector with A(N), H(N), V(N), D(N),
%H(N-1), V(N-1), D(N-1), ..., H(1), V(1), D(1), 
%where A, H, V, and D are each a row vector. 
%Each vector is the vector column-wise storage of a matrix.
[CX,S]=wavedec2(X,LN,wav);
[CY,S]=wavedec2(Y,LN,wav);
[ml,nl]=size(I);
[MX,NX]=size(X);
%output_most_possible_passage
HT=zeros(1,3);
%set_the_threshold
maxl=-1e2;
maxk=-1e2;
maxT=-1e2;
for k=1:LN
    if(ml<=MX/2^k&&nl<=NX/2^k)
        %[H,V,D] = detcoef2('all',C,S,N) returns the horizontal H, vertical V,
        %and diagonal D detail coefficients at level N.
        [HXk,VXk,DXk]=detcoef2('all',CX,S,k);
        [HYk,VYk,DYk]=detcoef2('all',CY,S,k);
        HT(1)=norm(xcorr2((HXk-HYk),I));
        HT(2)=norm(xcorr2((HXk-HYk),I));
        HT(3)=norm(xcorr2((DXk-DYk),I));
        %return_the_most_likely_position_of_watermark
        I=find(max(HT));
 
        if(max(HT)>maxT)
            maxT=max(HT);
            maxl=I;
            maxk=k;
        end
    end
end

t=maxl;
l=maxk;

end