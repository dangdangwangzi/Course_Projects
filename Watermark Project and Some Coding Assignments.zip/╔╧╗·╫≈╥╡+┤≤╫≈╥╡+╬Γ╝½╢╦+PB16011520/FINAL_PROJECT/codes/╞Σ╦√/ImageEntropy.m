%calculate_gray_value_of_an_image
function[H1,H2]=ImageEntropy(X)
%size_of_the_image
[Mx,Nx]=size(X);
%histogram_for_the_intensity_image
P1=imhist(X,256)./(Mx*Nx);

%calculate_one_dimensional_entropy
B1=find(P1~=0);
H1=-sum(P1(B1).*log2(P1(B1)));

%neighborhood
%constant_continuation
%column_continuation
temp1=[X(:,1),X,X(:,Nx)];
%row_continuation
temp2=[temp1(1,:);temp1;temp1(Mx,:)];

%for_each_pixel
f=zeros(256,256);
for t1=1:Mx
    for t2=1:Nx
        %four_connected_neighborhood
        i=round(temp2(t1+1,t2+1));
        j=round((temp2(t1+1,t2)+temp2(t1+1,t2+2)+temp2(t1,t2+1)+temp2(t1+2,t2+1))/4);
        
        %eight_connected_neighborhood
        %j=round((temp2(t1+1,t2)+temp2(t1+1,t2+2)+temp2(t1,t2+1)+temp2(t1+2,t2+1)+temp2(t1,t2)+temp2(t1,t2+2)+temp2(t1+2,t2)+temp2(t1+2,t2+2))/8);
        f(i+1,j+1)=f(i+1,j+1)+1;
    end
end
%frequency
P2=f./(Mx*Nx);
%calculate_2_dimensional_entropy
B2=find(P2~=0);
H2=-1*sum(sum(P2(B2).*log2(P2(B2))));

end