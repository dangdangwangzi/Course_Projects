%input_images
X=imread('Chrysanthemum.jpg');
Y=imread('Desert.jpg');
Z=imread('lin.jpg');
%calculate_gray_value
X1=rgb2gray(X);
X2=rgb2gray(Y);
X3=rgb2gray(Z);
[H1_x,H2_x]=ImageEntropy(X1);
[H1_y,H2_y]=ImageEntropy(X2);
[H1_z,H2_z]=ImageEntropy(X3);
sprintf('1 ord image entropy of Chrysanthemum is: %d',H1_x)
sprintf('2 ord image entropy of Chrysanthemum is: %d',H2_x)
sprintf('1 ord image entropy of Desert is: %d',H1_y)
sprintf('2 ord image entropy of Desert is: %d',H2_y)
imwrite(X1,'chrysanthemum_gray.jpg','jpg');
imwrite(X2,'desert_gray.jpg','jpg');
imwrite(X3,'lin_gray.jpg','jpg');
