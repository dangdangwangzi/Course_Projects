function CL=imstrech(C)
M=min(min(C));
N=max(max(C));
CL=(C-M)./(N-M)*255;
CL=uint8(CL);
end