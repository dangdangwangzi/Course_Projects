%input_true_color_images
X_water=imread('lin.jpg');
X_support=imread('Desert.jpg');
%change_into_gray_images
Y_water=rgb2gray(X_water);
Y_support=rgb2gray(X_support);
%calculate_image_entropy
[H1_x,H2_x]=ImageEntropy(Y_water);
[H1_y,H2_y]=ImageEntropy(Y_support);
%wavelet_transformation
[ca,ch,cv,cd]=dwt2(Y_support,'haar');
%for_different_frequencies
CA1=imstrech(ca);
CH1=imstrech(ch);
CV1=imstrech(cv);
CD1=imstrech(cd);
[H1_a,H2_a]=ImageEntropy(CA1);
[H1_h,H2_h]=ImageEntropy(CH1);
[H1_v,H2_v]=ImageEntropy(CV1);
[H1_d,H2_d]=ImageEntropy(CD1);
%decompose_low_frequency
[ca2,ch2,cv2,cd2]=dwt2(ca,'haar');

CA2=imstrech(ca2);
CH2=imstrech(ch2);
CV2=imstrech(cv2);
CD2=imstrech(cd2);

[H1_a2,H2_a2]=ImageEntropy(CA2);
[H1_h2,H2_h2]=ImageEntropy(CH2);
[H1_v2,H2_v2]=ImageEntropy(CV2);
[H1_d2,H2_d2]=ImageEntropy(CD2);

[H1_x,H1_y,H1_a,H1_h,H1_v,H1_d,H1_a2,H1_h2,H1_v2,H1_d2
    H2_x,H2_y,H2_a,H2_h,H2_v,H2_d,H2_a2,H2_h2,H2_v2,H2_d2]



