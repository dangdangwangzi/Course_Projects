
function RWR=MY_DCT_OUT(X_marked,K,k1,k2)
U_marked=X_marked(:,:,2);
U_marked=blkproc(U_marked,[8 8],'dct2');
p=zeros(1,8);
[Xm,Xn]=size(U_marked);
RWR=zeros(Xm/8,Xn/8);
for i=1:Xm/8
    for j=1:Xn/8
        x=(i-1)*8;y=(j-1)*8;
        p(1)=U_marked(x+1,y+8);
        p(2)=U_marked(x+2,y+7);
        p(3)=U_marked(x+3,y+6);
        p(4)=U_marked(x+4,y+5);
        p(5)=U_marked(x+5,y+4);
        p(6)=U_marked(x+6,y+3);
        p(7)=U_marked(x+7,y+2);
        p(8)=U_marked(x+8,y+1);
        if corr2(p,k1)>corr2(p,k2)
            RWR(i,j)=0;
        else
            RWR(i,j)=1;
        end
        
    end
end


end
