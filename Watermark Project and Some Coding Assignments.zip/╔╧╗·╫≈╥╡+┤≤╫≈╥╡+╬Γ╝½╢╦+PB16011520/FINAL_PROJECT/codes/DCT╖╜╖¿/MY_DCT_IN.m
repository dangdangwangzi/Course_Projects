
function X_marked=MY_DCT_IN(X_in,WM,K,alpha,k1,k2)
[Im,In]=size(WM);

X_marked=blkproc(X_in,[8 8],'dct2');
for i=1:Im
    for j=1:In
        x=(i-1)*8;
        y=(j-1)*8;
        if WM(i,j)==1
            k=k1;
        else
            k=k2;
        end;
        X_marked(x+1,y+8)=X_marked(x+1,y+8)+alpha*k(1);
        X_marked(x+2,y+7)=X_marked(x+2,y+7)+alpha*k(2);
        X_marked(x+3,y+6)=X_marked(x+3,y+6)+alpha*k(3);
        X_marked(x+4,y+5)=X_marked(x+4,y+5)+alpha*k(4);
        X_marked(x+5,y+4)=X_marked(x+5,y+4)+alpha*k(5);
        X_marked(x+6,y+3)=X_marked(x+6,y+3)+alpha*k(6);
        X_marked(x+7,y+2)=X_marked(x+7,y+2)+alpha*k(7);
        X_marked(x+8,y+1)=X_marked(x+8,y+1)+alpha*k(8);
    end
end

X_marked=blkproc(X_marked,[8 8],'idct2');

end





