%interaction_to_improve_UE
disp('Choose a watermark');
[filename, pathname] = uigetfile('*.jpg', 'Read image file');
pathfile=fullfile(pathname, filename);
WM=imread(pathfile); 
disp('Choose a host image');
[filename2, pathname2] = uigetfile('*.jpg', 'Read image file');
pathfile2=fullfile(pathname2, filename2);
X=imread(pathfile2); 

WM=jpg_to_gray(WM);
figure(1)
subplot(1,3,1)
imshow(WM);
title('Watermark');

subplot(1,3,2)
imshow(X)
title('Original host image');

%define_block_num
K=8;
%set_intensity
alpha=30;
%generate_random_numbers
k1=randn(1,8);
k2=randn(1,8);

yuv=rgb2ycbcr(X);
Y=yuv(:,:,1);
U=yuv(:,:,2);
V=yuv(:,:,3);
[Xm,Xn]=size(U);
WM=imresize(WM,[Xm/8,Xn/8]);
U_marked=MY_DCT_IN(U,WM,K,alpha,k1,k2);
X_marked=cat(3,Y,U_marked,V);
%change_format
X_marked=ycbcr2rgb(X_marked);
imwrite(X_marked,'watermarked_dct.jpg','jpg');
subplot(1,3,3)
imshow(X_marked)
title('Watermarked with DCT')

disp('Choose attacking method from methods listed below');
disp('1.shearing attack');
disp('2.Rotating attack');
disp('3.Resampling attack');
disp('4.Noise attack');
disp('5.bluring attack');
disp('6.Compressing attack');
disp('Other input: Show the retrieved watermark directly');
choice=input('Please input your choice:');
%different_attacks
switch choice
case 1

[X_LU,X_RD]=shearing_attack(X_marked);
%X_LU=ycbcr2rgb(X_LU);
Restored_WM=MY_DCT_OUT(X_LU,K,k1,k2);
figure(2)
subplot(1,3,1);
imshow(X_LU),title('After LU')
subplot(1,3,2);
imshow(Restored_WM,[]),title('After LU');
subplot(1,3,3);
imshow(WM),title('Original watermark');

Restored_WM=MY_DCT_OUT(X_RD,K,k1,k2);
figure(3)
subplot(1,3,1);
imshow(X_RD),title('After RD')
subplot(1,3,2);
imshow(Restored_WM,[]),title('After RD');
subplot(1,3,3);
imshow(WM),title('Original watermark');


case 2
X_R=rotating_attack(X_marked);
Restored_WM=MY_DCT_OUT(X_R,K,k1,k2);
figure(2)
subplot(1,3,1);
imshow(X_R),title('After rotating')
subplot(1,3,2)
imshow(Restored_WM),title('After rotating');
subplot(1,3,3)
imshow(WM),title('Original watermark');

case 3
X_RS2=resampling_attack(X_marked);
Restored_WM=MY_DCT_OUT(X_RS2,K,k1,k2);
figure(2)
subplot(1,3,1)
imshow(uint8(X_RS2)),title('After resampling')
subplot(1,3,2)
imshow(Restored_WM),title('After resampling');
subplot(1,3,3)
imshow(WM),title('Original watermark');

case 4
X_N=noise_attack(X_marked);
Restored_WM=MY_DCT_OUT(X_N,K,k1,k2);
figure(2)
subplot(1,3,1)
imshow(X_N),title('After noise attack')
subplot(1,3,2)
imshow(Restored_WM),title('After noise attack')
subplot(1,3,3)
imshow(WM),title('Original watermark');

case 5
X_B=bluring_attack(X_marked);
Restored_WM=MY_DCT_OUT(X_B,K,k1,k2);
figure(2)
subplot(1,3,1)
imshow(X_B),title('After bluring')
subplot(1,3,2)
imshow(Restored_WM),title('After bluring')
subplot(1,3,3)
imshow(WM),title('Original watermark');

case 6
X_C=compressing_attack(X_marked);
Restored_WM=MY_DCT_OUT(X_C,K,k1,k2);
figure(2)
subplot(1,3,1)
imshow(X_C),title('After compressing')
subplot(1,3,2)
imshow(Restored_WM),title('After compressing')
subplot(1,3,3)
imshow(WM),title('Original watermark')

otherwise
Restored_WM=MY_DCT_OUT(X_marked,K,k1,k2);
figure(4)
subplot(1,2,1);
imshow(Restored_WM,[]),title('Retrieved watermark');
subplot(1,2,2);
imshow(WM),title('Original watermark');
end






