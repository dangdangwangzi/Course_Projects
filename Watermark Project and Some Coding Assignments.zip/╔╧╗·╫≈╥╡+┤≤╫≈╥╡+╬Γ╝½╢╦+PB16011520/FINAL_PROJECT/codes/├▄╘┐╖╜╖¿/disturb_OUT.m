%X_original_host_image
%Y_disturbed_watermark
function D=disturb_OUT(X,Y,wav,lev,p1,p2,T1,T2,N)
[CX,SX]=wavedec2(X,lev,wav);
[CY,SY]=wavedec2(Y,lev,wav);
D=zeros(N);

fx1=detcoef2('h',CX,SX,1);
fy1=detcoef2('h',CY,SY,1);
%calculate_difference
theta=fy1(p1+1:p1+N,p2+1:p2+N)-fx1(p1+1:p1+N,p2+1:p2+N);

for i=1:N
    for j=1:N
        if(abs(theta(i,j))>=(T1+T2)/2)
            D(i,j)=1;
        else
            D(i,j)=0;
        end
    end
end
%Any nonzero element of A is converted to logical 1 (true) and zeros are converted to logical 0 (false). 
D=logical(D);
end