%X_original_image
%S,T1,T2,(p1,p2)_in_algorithm
%embedding_position_LH1_passage
%

function Y=disturb_IN(X,I,wav,lev,U,p1,p2,S,T1,T2)
[Mi,Ni]=size(I);
[Mu,Nu]=size(U);

[CX,SX]=wavedec2(X,lev,wav);
f1=detcoef2('h',CX,SX,1);

[fm,fn]=size(f1);
MNi=Mi*Ni;
if(p1+Mi>fm||p2+Ni>fn)
    msg='Offset is out of range';
    errors(msg);
end

%embedding
for i=1:Nu
    Ui=U(1,i);
    Uj=U(2,i);
    ff=f1(p1+Ui,p2+Uj);
    deta=mod(ff,S);
    if(I(Ui,Uj)==1)
        if(ff>=0)
            ff=ff-deta+T1;
        else
            ff=ff+deta-T1;
        end
    else
        if(ff>=0)
            ff=ff-deta+T2;
        else
            ff=ff+deta-T2;
        end
    end
    f1(p1+Ui,p2+Uj)=ff;
end

CX(SX(lev+1,1)*SX(lev+1,2)+1:SX(lev+1,1)*SX(lev+1,2)*2)=f1(:)';

%reconstruct
Y=waverec2(CX,SX,wav);

end