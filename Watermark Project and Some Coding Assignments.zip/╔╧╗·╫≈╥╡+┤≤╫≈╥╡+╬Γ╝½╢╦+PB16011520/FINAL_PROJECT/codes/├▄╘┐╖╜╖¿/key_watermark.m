%choose_gray_value_images
%interaction_to_improve_UE
%improve_to_colorful_image
disp('Choose a watermark');
[filename, pathname] = uigetfile('*.jpg', 'Read image file');
pathfile=fullfile(pathname, filename);
I=imread(pathfile); 
I=rgb2gray(I);
I=imbinarize(I);

disp('Choose a host image');
[filename2, pathname2] = uigetfile('*.jpg', 'Read image file');
pathfile2=fullfile(pathname2, filename2);
X=imread(pathfile2); 


%set_parameters
k=3;
T=180;
NT=192;
N=256;
T1=5;
T2=10;
S=2;
p1=0;
p2=0;
lev=3;
%cycle_NT
%disturb_watermark
[Y,U]=disturb(I,k,N,T);
%embedding_watermark
Y_out=disturb_IN(X,Y,'haar',lev,U,p1,p2,S,T1,T2);
PP=psnr(X,uint8(Y_out));
%retreive_watermark_by_continuing_disturbing_for_NT-T_times
D=disturb_OUT(X,Y_out,'haar',lev,p1,p2,T1,T2,N);
[I_out,U]=disturb(D,k,N,NT-T);

%draw_jpgs
figure(1)
subplot(1,2,1)
imshow(I,[])
title('Original watermark');
subplot(1,2,2)
imshow(Y,[])
title('Disturbed watermark,k=3,T=180')
imwrite(Y,'disturbed_watermark.jpg','jpg');

figure(2)
subplot(1,3,1)
imshow(X,[])
title('Original');
subplot(1,3,2)
imshow(uint8(Y_out),[])
title('With disturbed watermark');
imwrite(uint8(Y_out),'host_image_with_disturbed_watermark.jpg','jpg');
subplot(1,3,3)
imshow(uint8(Y_out)-X,[])
title('Difference');

figure(3)
subplot(1,2,1)
imshow(I,[])
title('Original watermark');
subplot(1,2,2)
imshow(I_out,[])
title('Restored watermark');
imwrite(I_out,'restored_watermark.jpg','jpg');
