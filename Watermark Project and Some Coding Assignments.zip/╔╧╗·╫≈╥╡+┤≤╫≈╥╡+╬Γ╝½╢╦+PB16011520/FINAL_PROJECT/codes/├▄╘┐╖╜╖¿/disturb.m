%disturb_watermark
%X_watermark_image
%Y_diturbed_watermark
%T_disturbing_times
%k_disturbing_parameter
%use_gray_image
%U_pixel_new_position_in_disturbed_watermark,2*(N^2)
function [Y,U]=disturb(X,k,N,T)
[MX,NX]=size(X);
Y=zeros(N);
Y_temp=Y;
%disturbing_matrix
A=[1 1
    k k+1];
U=[];

%disturb_for_the_first_time
%record_new_position_of_pixels
for i=1:MX
    for j=1:NX
        Tn=mod(A*[i j]',N);
        Y(Tn(1)+1,Tn(2)+1)=X(i,j);
        U=[U,[Tn(1)+1,Tn(2)+1]'];
    end
end

for tt=1:T-1
    U_temp=[];
    for i=1:MX*NX
        Ui=U(1,i);
        Uj=U(2,i);
        Tn=mod(A*[Ui Uj]',N);
        Y_temp(Tn(1)+1,Tn(2)+1)=Y(Ui,Uj);
        U_temp=[U_temp,[Tn(1)+1,Tn(2)+1]'];
    end
    Y=Y_temp;
    U=U_temp;
end
end