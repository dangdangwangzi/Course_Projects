function D=invChao(B,numy)
C=uint8(B);
[M,N]=size(C);

C1=reshape(C,1,M*N);
%rebuiid_image_through_position_vector
for t=1:M*N
    D1(numy(t))=C1(t);
end

D=reshape(D1,M,N);
end