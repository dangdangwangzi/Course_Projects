%key_initial_value
function [B,numy]=chao(A,key)

[Xm,Xn]=size(A);
%change_into_a_row_vector
A1=reshape(A,1,Xm*Xn);
y1(1)=key;
%recursion_formula
for n=1:Xm*Xn-1
    y1(n+1)=4*sin(y1(n)-2.5)*sin(y1(n)-2.5);
end
%position_vector_numy
[y2,numy]=sort(y1);
for t=1:Xm*Xn
    B1(t)=A1(numy(t));
end

B=reshape(B1,Xm,Xn);

end