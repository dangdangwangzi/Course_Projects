function I_out=CH_OUT(X,X_out,a,b,r1,r2,r3,r4)
%decompose_for_3_levels
%for_original_image
[CA1,CH1,CV1,CD1]=dwt2(X,'haar');
[CA2,CH2,CV2,CD2]=dwt2(CA1,'haar');
[CA3,CH3,CV3,CD3]=dwt2(CA2,'haar');
%for_image_with_watermark
[CCA1,CCH1,CCV1,CCD1]=dwt2(X_out,'haar');
[CCA2,CCH2,CCV2,CCD2]=dwt2(CCA1,'haar');
[CCA3,CCH3,CCV3,CCD3]=dwt2(CCA2,'haar');

[Xm,Xn]=size(CCD3);

watermark1=zeros(Xm,Xn);
watermark2=zeros(Xm,Xn);
watermark3=zeros(Xm,Xn);
watermark4=zeros(Xm,Xn);
watermark5=zeros(Xm,Xn);
watermark6=zeros(Xm,Xn);

ICA1=zeros(Xm,Xn);

for i=1:round(Xm/2)
    for j=1:Xn
        watermark1(i,j)=(double(CCD2(r1(i),r2(j)))-double(CD2(r1(i),r2(j))))/b;
        watermark2(i,j)=(double(CCV2(r1(i),r2(j)))-double(CV2(r1(i),r2(j))))/b;
        watermark3(i,j)=(double(CCH2(r1(i),r2(j)))-double(CH2(r1(i),r2(j))))/b;
    end
end

for i=round(Xm/2)+1:Xm
    for j=1:Xn
        watermark4(i,j)=(double(CCD3(r3(i),r4(j)))-double(CD3(r3(i),r4(j))))/b;
        watermark5(i,j)=(double(CCV3(r3(i),r4(j)))-double(CV3(r3(i),r4(j))))/b;
        watermark6(i,j)=(double(CCH3(r3(i),r4(j)))-double(CH3(r3(i),r4(j))))/b;
    end
end
%high_frequency
ICD1=watermark1+watermark4;
ICV1=watermark2+watermark5;
ICH1=watermark3+watermark6;
for i=1:Xm
    for j=1:Xn
        ICA1(i,j)=(double(CCA3(i,j))-double(CA3(i,j)))/a;
    end
end

I_out=idwt2(ICA1,ICH1,ICV1,ICD1,'haar');

end