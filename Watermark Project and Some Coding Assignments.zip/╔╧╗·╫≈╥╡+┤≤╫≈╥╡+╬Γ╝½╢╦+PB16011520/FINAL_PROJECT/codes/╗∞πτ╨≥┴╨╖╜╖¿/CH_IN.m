%r1,r2,r3,r4_random_serial
function X_out=CH_IN(X,I,a,b,r1,r2,r3,r4)
%wavelet_decomposition_level1
[CA1,CH1,CV1,CD1]=dwt2(X,'haar');
%wavelet_decomposition_level2
[CA2,CH2,CV2,CD2]=dwt2(CA1,'haar');
%wavelet_decomposition_level3
[CA3,CH3,CV3,CD3]=dwt2(CA2,'haar');
[Xm,Xn]=size(CD3);
%decompose_watermark
[ICA1,ICH1,ICV1,ICD1]=dwt2(I,'haar');

%embed_high_frequency
for i=1:round(Xm/2)
    for j=1:Xn
        CD2(r1(i),r2(j))=double(CD2(r1(i),r2(j)))+b*double(ICD1(i,j));
        CV2(r1(i),r2(j))=double(CV2(r1(i),r2(j)))+b*double(ICV1(i,j));
        CH2(r1(i),r2(j))=double(CH2(r1(i),r2(j)))+b*double(ICH1(i,j));
    end
end

for i=round(Xm/2)+1:Xm
    for j=1:Xn
        CD3(r3(i),r4(j))=double(CD3(r3(i),r4(j)))+b*double(ICD1(i,j));
        CV3(r3(i),r4(j))=double(CV3(r3(i),r4(j)))+b*double(ICV1(i,j));
        CH3(r3(i),r4(j))=double(CH3(r3(i),r4(j)))+b*double(ICH1(i,j));
    end
end
%embed_low_frequency
CA3=double(CA3)+a*double(ICA1);
%inverse_wavelet_transform
x3=idwt2(CA3,CH3,CV3,CD3,'haar');
x2=idwt2(x3,CH2,CV2,CD2,'haar');
X_out=idwt2(x2,CH1,CV1,CD1,'haar');

end