disp('Choose a watermark');
[filename, pathname] = uigetfile({'*.jpg';'*.bmp'}, 'Read image file');
pathfile=fullfile(pathname, filename);
I=imread(pathfile); 
if(length(size(I))==3)
    I=rgb2gray(I);
end

disp('Choose a host image');
[filename2, pathname2] = uigetfile({'*.jpg';'*.bmp'}, 'Read image file');
pathfile2=fullfile(pathname2, filename2);
image=imread(pathfile2);
if(length(size(image))==3)
    %X=imread(pathfile2);
    Y=image(:,:,1);
    X=image(:,:,2);
    V=image(:,:,3);
    [Xm,Xn]=size(X);
    I=imresize(I,[Xm/4,Xn/4]);
else
    X=image;
    [Xm,Xn]=size(X);
    I=imresize(I,[Xm/4,Xn/4]);
end
key=3.6;

disp('Choose attacking method from methods listed below');
disp('1.shearing attack');
disp('2.Rotating attack');
disp('3.Resampling attack');
disp('4.Noise attack');
disp('5.bluring attack');
disp('6.Compressing attack');
disp('Other input: Show the retrieved watermark directly');
choice=input('Please input your choice:');

%set_parameters
a=0.2;
b=0.08;
[Im,In]=size(I);
[Xm,Xn]=size(X);
%generate_random_serials
r1=randperm(Im);
r2=randperm(In);
r3=randperm(Im/2);
r4=randperm(In/2);
[I,numy]=chao(I,key);
X_out=CH_IN(X,I,a,b,r1,r2,r3,r4);


%attack_and_retrieve
switch choice
    case 1
        [X_LU,X_RD]=shearing_attack(uint8(X_out));
        I_LU=CH_OUT(X,X_LU,a,b,r1,r2,r3,r4);
        I_RD=CH_OUT(X,X_RD,a,b,r1,r2,r3,r4);
        I_LU=invChao(I_LU,numy);
        I_RD=invChao(I_RD,numy);
        %true_color_images
        if(length(size(image))==3)
            X_out=cat(3,Y,X_out,V);
            [X_LU,X_RD]=shearing_attack(uint8(X_out));
        end
        
        figure(1)
        subplot(1,2,1)
        imshow(X_LU)
        title('Shear LU')
        subplot(1,2,2)
        imshow(I_LU)
        title('Retrieved watermark')
        
        figure(2)
        subplot(1,2,1)
        imshow(X_RD)
        title('Shear RD')
        subplot(1,2,2)
        imshow(I_RD)
        title('Retrieved watermark')
        
    case 2
        X_R=rotating_attack(uint8(X_out));
        I_R=CH_OUT(X,X_R,a,b,r1,r2,r3,r4);
        I_R=invChao(I_R,numy);
        
        if(length(size(image))==3)
            X_out=cat(3,Y,uint8(X_out),V);
            X_R=rotating_attack(uint8(X_out));
        end
        
        figure(1)
        subplot(1,2,1)
        imshow(X_R)
        title('After Rotating attack')
        subplot(1,2,2)
        imshow(I_R)
        title('Retrieved watermark')
    case 3
        X_RS2=resampling_attack(uint8(X_out));
        I_RS2=CH_OUT(X,X_RS2,a,b,r1,r2,r3,r4);
        I_RS2=invChao(I_RS2,numy);
        
        if(length(size(image))==3)
            X_out=cat(3,Y,uint8(X_out),V);
            X_RS2=resampling_attack(uint8(X_out));
        end
        
        figure(1)
        subplot(1,2,1)
        imshow(uint8(X_RS2))
        title('After resampling attack')
        subplot(1,2,2)
        imshow(I_RS2)
        title('Retrieved watermark')
    case 4
        X_N=noise_attack(uint8(X_out));
        I_N=CH_OUT(X,X_N,a,b,r1,r2,r3,r4);
        I_N=invChao(I_N,numy);
        
         if(length(size(image))==3)
            X_out=cat(3,Y,uint8(X_out),V);
            X_N=noise_attack(uint8(X_out));
        end
        figure(1)
        subplot(1,2,1)
        imshow(uint8(X_N))
        title('After noise attack')
        subplot(1,2,2)
        imshow(uint8(I_N))
        title('Retrieved watermark')
        
    case 5
        X_B=bluring_attack(uint8(X_out));
        I_B=CH_OUT(X,X_B,a,b,r1,r2,r3,r4);
        I_B=invChao(I_B,numy);
        
         if(length(size(image))==3)
            X_out=cat(3,Y,uint8(X_out),V);
            X_B=bluring_attack(uint8(X_out));
         end
        
         figure(1)
         subplot(1,2,1)
         imshow(uint8(X_B))
         title('After blurring attack')
         subplot(1,2,2)
         imshow(uint8(I_B))
         title('Retrieved watermark')
    case 6
        X_C=compressing_attack(uint8(X_out));
        I_C=CH_OUT(X,X_C,a,b,r1,r2,r3,r4);
        I_C=invChao(I_C,numy);
        
         if(length(size(image))==3)
            X_out=cat(3,Y,uint8(X_out),V);
            X_C=compressing_attack(uint8(X_out));
        end
        
        figure(1)
        subplot(1,2,1)
        imshow(uint8(X_C))
        title('After compressing attack')
        subplot(1,2,2)
        imshow(uint8(I_C))
        title('Retrieved watermark')
    otherwise
        
        I_NA=CH_OUT(X,X_out,a,b,r1,r2,r3,r4);
        I_NA=invChao(I_NA,numy);
        figure
        if(length(size(image))==3)
            X_out=cat(3,Y,uint8(X_out),V);
        end
        subplot(1,2,1)
        imshow(X_out)
        title('Watermarked')
        subplot(1,2,2)
        imshow(I_NA)
        title('Retrieved watermark without attacking');
        
end

