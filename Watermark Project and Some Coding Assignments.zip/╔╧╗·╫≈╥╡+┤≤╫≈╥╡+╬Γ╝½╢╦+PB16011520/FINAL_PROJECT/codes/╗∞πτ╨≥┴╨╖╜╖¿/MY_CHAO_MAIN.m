disp('Choose a watermark');
[filename, pathname] = uigetfile({'*.jpg';'*.bmp'}, 'Read image file');
pathfile=fullfile(pathname, filename);
I=imread(pathfile); 
if(length(size(I))==3)
    I=rgb2gray(I);
end

disp('Choose a host image');
[filename2, pathname2] = uigetfile({'*.jpg';'*.bmp'}, 'Read image file');
pathfile2=fullfile(pathname2, filename2);
image=imread(pathfile2);
if(length(size(image))==3)
    %X=imread(pathfile2);
    Y=image(:,:,1);
    X=image(:,:,2);
    V=image(:,:,3);
    [Xm,Xn]=size(X);
    I=imresize(I,[Xm/4,Xn/4]);
else
    X=image;
    [Xm,Xn]=size(X);
    I=imresize(I,[Xm/4,Xn/4]);
end
%disturb_watermark
key=3.6;
[I_out,numy]=chao(I,key);
IN_I=invChao(I_out,numy);



figure(1)
subplot(1,3,1),imshow(I),title('Original watermark')
subplot(1,3,2),imshow(I_out),title('Disturbed watermark')
subplot(1,3,3),imshow(uint8(IN_I)),title('Decoded watermark');

%set_parameters
a=0.2;
b=0.08;
[Im,In]=size(I);
[Xm,Xn]=size(X);
%generate_random_serials
r1=randperm(Im);
r2=randperm(In);
r3=randperm(Im/2);
r4=randperm(In/2);

X_out=CH_IN(X,I_out,a,b,r1,r2,r3,r4);

I_R=CH_OUT(X,X_out,a,b,r1,r2,r3,r4);
I_R=invChao(I_R,numy);
figure(2)
subplot(1,2,1)
if(length(size(image))==3)
    X_out=cat(3,Y,X_out,V);
end
imshow(uint8(X_out))
title('Watermarked Chao')
imwrite(X_out,'Watermarked_Chao.jpg','jpg');
subplot(1,2,2)
imshow(uint8(I_R))
title('Retrieved watermark')
imwrite(I_R,'Retrieved_watermark_Chao.jpg','jpg');







