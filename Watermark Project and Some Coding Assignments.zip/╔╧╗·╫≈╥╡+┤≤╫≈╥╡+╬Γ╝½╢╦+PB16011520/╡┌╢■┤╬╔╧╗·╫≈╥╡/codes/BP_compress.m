function Y=BP_compress(I)
[Xm,Xn]=size(I);
% I=imread('lin_gray.jpg');
% I=imresize(I,[128,128]);
Xm=round(Xm/4)*4;
Xn=round(Xn/4)*4;
I=imresize(I,[Xm,Xn]);

P=[];
for i=1:Xm/4
    for j=1:Xn/4
        I2=I((i-1)*4+1:i*4,(j-1)*4+1:j*4);
        i3=reshape(I2,[16,1]);
        I1=double(i3);
        %normalization
        P_1=I1/255;
        P=[P,P_1];
    end
end
T=P;
net=newff(minmax(P),[2,16],{'tansig','logsig'},'trainlm');
net.trainParam.goal=0.001;
net.trainParam.epochs=500;
tic
net=train(net,P,T);
toc
Y_cg=sim(net,P);
Y_cg_test=[];
for k=1:Xm/4*Xn/4
    Y_cg_test1=reshape(Y_cg(:,k),4,4);
    Y_cg_test=[Y_cg_test,Y_cg_test1];
end
YY_cg_test=[];
for k=1:Xm/4
    YY_cg_test1=Y_cg_test(:,(k-1)*Xn+1:k*Xn);
    YY_cg_test=[YY_cg_test;YY_cg_test1];
end
Y=uint8(YY_cg_test*255);

end








