X=imread('61507.jpeg');
if(length(size(X))==3)
    Y=X(:,:,1);
    Y=BP_compress(Y);
    U=X(:,:,2);
    U=BP_compress(U);
    V=X(:,:,3);
    V=BP_compress(V);
    Y=cat(3,Y,U,V);
else
    Y=BP_compress(X);
end

figure(1)
subplot(1,2,1)
imshow(X)
title('Original image')
subplot(1,2,2)
imshow(Y)
title('After')
